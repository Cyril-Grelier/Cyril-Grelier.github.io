#ifndef UTILS_H
#define UTILS_H

int add(int a, int b);

#endif // UTILS_H
